/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.kevinzamora.parcial2_tarea;

/**
 *
 * @author kzdesigner
 */
public class PARCIAL2_Tarea {

    public static void main(String[] args) {
        
        Principal principalObj = new Principal();
        principalObj.showCalculadora();
        
    }
        
}
