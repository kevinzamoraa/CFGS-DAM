/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kevinzamora.prog07_tarea.Model;

/**
 *
 * @author kzdesigner
 */
public class CuentaCorriente extends CuentaBancaria {
    /* No hemos entendido necesária su implementación en el presente ejercicio y además se nos 
    hemos encontrado considerablemente inhabilitados atencionalmente como para poder trabajar 
    con tantas clases*/
}
