/* No he conseguido organizar mis ideas como para lograr implementar correctamente 
la interfaz solicitada. Según tengo entendido, las interfaces sirven para definir entidades o 
para encapsular el uso de los métodos de una o varias clases, dificultando así su acceso indeseado */

///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
// */
//package kevinzamora.prog07_tarea.Controler;
//
//import java.util.ArrayList;
//import kevinzamora.prog07_tarea.Model.CuentaBancaria;
//import kevinzamora.prog07_tarea.Model.Persona;
//
///**
// *
// * @author kzdesigner
// */
//public class Imprimible {
//    
//    public String devolverInfoString(ArrayList<CuentaBancaria> listaCuentas, 
//            CuentaBancaria cuenta) {
//        String infoCuenta = "";
//        if() {}
//        
//        return infoCuenta;
//    }
//    
//}
