/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package kevinzamora.prog06_tarea;

/**
 *
 * @author kzdesigner
 */
public class PROG06_Tarea {

    public static void main(String[] args) {
        
        Principal principalObj = new Principal();
        principalObj.loadMainMenu();
        
    }
}
