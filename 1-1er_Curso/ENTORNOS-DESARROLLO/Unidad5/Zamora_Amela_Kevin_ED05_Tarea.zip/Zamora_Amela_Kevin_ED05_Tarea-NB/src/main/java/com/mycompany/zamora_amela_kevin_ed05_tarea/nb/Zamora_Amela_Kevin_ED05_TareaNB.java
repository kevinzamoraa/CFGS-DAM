/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.zamora_amela_kevin_ed05_tarea.nb;

/**
 *
 * @author kzdesigner
 */
public class Zamora_Amela_Kevin_ED05_TareaNB {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
