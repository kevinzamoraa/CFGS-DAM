/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package kevinzamora.prog05_ejerc1;

/**
 *
 * @author kzdesigner  // Autor y nombre del equipo de Kevin Zamora Amela
 */
public class PROG05_Ejerc1 {

    public static void main(String[] args) {
        
//        Vehiculo vehiculoObj = new Vehiculo();
//        float antiguedad = vehiculoObj.get_Anios(2015);
//        System.out.println("Antiguedad: " + antiguedad);

        Principal principalObj = new Principal();
        principalObj.loadMainMenu();
        
    }
}
