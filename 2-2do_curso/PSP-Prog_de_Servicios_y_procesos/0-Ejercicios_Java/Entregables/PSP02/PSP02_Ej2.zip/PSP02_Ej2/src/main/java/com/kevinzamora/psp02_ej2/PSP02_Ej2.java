/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.kevinzamora.psp02_ej2;

import ejercicio2.Principal;

/**
 *
 * Clase auxiliar para poder lanzar nuestra aplicación en Netbeans de forma 'nativa'
 * @author kzdesigner
 */
public class PSP02_Ej2 {
    /**
     * Método principal dedicado a inicializar y ejecutar nuestra aplicación
     * @param args Argumentos del método 'main'
     * retorna 'void'
     */
    public static void main(String[] args) {
        // Instanciamos la clase Principal y llamamos a su método 'main'
        Principal principalObj = new Principal();
        principalObj.main();
        
    }
    
}
