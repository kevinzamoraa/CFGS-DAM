from odoo import models, fields

class User(models.Models):
    _name = 'gestion.usuario'
    _description = 'Usuario personalizado'

    nombre = fields.char(string='Nombre')
    email = fields.char(string='Correo electronico')
    idioma = fields.Selection([
        ('es_ES', 'Español')
    ], string='idiona', default='es_ES')
    zona_horaria = fields.Selection([
        ('Europe/Madrid', 'Madrid'),
    ], string='Zona Horaria', default='Europe/Madrid')