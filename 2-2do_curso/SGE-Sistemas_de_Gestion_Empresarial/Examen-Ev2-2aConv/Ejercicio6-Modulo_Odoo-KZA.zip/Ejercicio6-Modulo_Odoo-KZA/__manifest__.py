{
    'depends': ['base'],
    'data': [
        'views/user_views.xml'
    ]
    'installable': True,
    'application': True,
    'license': 'LGPL-3'
}