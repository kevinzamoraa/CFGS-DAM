from odoo import models, fields

class CustomUser(models.Model):
    _name = "custom.user"
    _description = "Usuario Personalizado"

    name = fields.Char(string="Nombre", required=True)
    email = fields.Char(string="Correo electrónico")
    lang = fields.Selection(selection=[('es_ES', 'Español'), ('en_US', 'Inglés')], string="Idioma")
    timezone = fields.Selection(selection=[('Europe/Madrid', 'Madrid'), ('UTC', 'UTC')], string="Zona Horaria")
