{
    "name": "User Management",
    "version": "1.0",
    "depends": ["base"],
    "author": "Kevin Zamora",
    "category": "Tools",
    "summary": "Gestión personalizada de usuarios",
    "description": "Módulo para gestionar usuarios con nombre, email, idioma y zona horaria.",
    "data": ["views/user_views.xml"],
    "installable": True,
    "application": True,
    "auto_install": False
}
