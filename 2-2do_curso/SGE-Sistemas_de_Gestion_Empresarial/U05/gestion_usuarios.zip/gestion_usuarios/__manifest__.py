{
    'name': 'Gestión de Usuarios',
    'version': '1.0',
    'author': 'Tu Nombre',
    'category': 'Herramientas',
    'summary': 'Módulo para gestionar usuarios personalizados',
    'depends': ['base'],
    'data': [
        'views/user_views.xml',
    ],
    'installable': True,
    'application': True,
    'license': 'LGPL-3',
}

