{
    "name": "Gestión de Usuarios",
    "version": "1.0",
    "author": "Kevin Zamora",
    "category": "Herramientas",
    "summary": "Módulo para gestionar usuarios personalizados",
    "depends": ["base"],
    "data": [
        "views/user_views.xml"
    ],
    "installable": true,
    "application": true,
    "license": "LGPL-3"
}
