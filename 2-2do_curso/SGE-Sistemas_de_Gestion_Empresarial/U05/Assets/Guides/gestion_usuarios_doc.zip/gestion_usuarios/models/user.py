from odoo import models, fields

class GestionUsuarios(models.Model):
    _name = 'gestion.usuarios'
    _description = 'Gestión de Usuarios'

    name = fields.Char(string='Nombre', required=True)
    email = fields.Char(string='Correo Electrónico')
    language = fields.Selection([
        ('es_ES', 'Español'),
        ('en_US', 'Inglés')
    ], string='Idioma', default='es_ES')
    timezone = fields.Selection([
        ('Europe/Madrid', 'Madrid'),
        ('UTC', 'UTC')
    ], string='Zona Horaria', default='Europe/Madrid')
