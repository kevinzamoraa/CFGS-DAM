{
    "name": "Gestión de Usuarios",
    "version": "1.0",
    "category": "Custom",
    "summary": "Gestión básica de usuarios personalizados",
    "description": "Módulo que permite gestionar usuarios con campos personalizados como nombre, email, idioma y zona horaria.",
    "author": "Kevin Zamora",
    "depends": ["base"],
    "data": ["views/user_views.xml"],
    "installable": True,
    "application": True,
    "auto_install": False
}
