Observaciones para el profesor/a:
Este proyecto contiene la interfaz solicitada para la gestión de reservas del "Salón Caribe".
El estilo ha sido diseñado con una estética moderna y minimalista, utilizando colores violetas y tonos claros.
Las clases y métodos están nombrados en inglés, con nombres fácilmente comprensibles.

IDE recomendado: VS Code con extensión C# de OmniSharp.
