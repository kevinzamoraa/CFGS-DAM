/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.kevinzamora.ad05_tarea;

/**
 *
 * @author kzdesigner
 */
public class AD05Tarea {

    public static void main(String[] args) {
        MenuPrincipal menuPrincipalObj = new MenuPrincipal();
        menuPrincipalObj.mostrarMenu();
    }
}
