/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package examen_ad_mayo25_ej1;

/**
 *
 * @author Kevin
 */
public class ExamenAD_Mayo25_Ej1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MenuPrincipal menuPrincipalObj = new MenuPrincipal();
        menuPrincipalObj.mostrarMenu();
    }
    
}
