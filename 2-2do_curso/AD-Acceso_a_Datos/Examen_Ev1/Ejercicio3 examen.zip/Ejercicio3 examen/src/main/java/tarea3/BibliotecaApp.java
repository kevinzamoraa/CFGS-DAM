package tarea3;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.time.LocalDate;
import java.util.List;

public class BibliotecaApp {

    public static void main(String[] args) {

        // llamar a los 3 métodos parcialmente implementados
        
    }

    // Mostrar los libros disponibles
    public static void mostrarLibrosDisponibles() {

        // Implementa la lógica para mostrar los libros disponibles.
        // Debes realizar una consulta usando HQL para obtener todos los libros donde 'disponible = true'.
    
    }

    // Insertar un préstamo
    public static void insertarPrestamo(int idLibro, String nombreUsuario) {
        // Implementa la lógica para registrar un préstamo.
        // Recuerda:
        // 1. Verificar si el libro existe y está disponible.
        // 2. Cambiar el estado del libro a 'no disponible'.
        // 3. Guardar el préstamo en la base de datos.

    }

    // Borrar un préstamo
    public static void borrarPrestamo(int idPrestamo) {
        // Implementa la lógica para eliminar un préstamo.
        // Recuerda:
        // 1. Obtener el préstamo por su ID.
        // 2. Cambiar el estado del libro a 'disponible'.
        // 3. Eliminar el préstamo de la base de datos.

    }
}
